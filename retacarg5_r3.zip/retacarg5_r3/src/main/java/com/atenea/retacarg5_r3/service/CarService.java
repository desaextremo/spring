package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {
    @Autowired
    CarRepository repository;

    //listar carros
    public List<Car> getCars(){
        return repository.findAll();
    }

    //registrar un carro
    public void addCar(Car car){
        repository.save(car);
    }
}
