package com.atenea.retacarg5_r3.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="gamas")
public class Gama {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idGama;
    @Column(nullable = false,length = 45)
    private String name;
    @Column(nullable = false,length = 250)
    private String description;
}
