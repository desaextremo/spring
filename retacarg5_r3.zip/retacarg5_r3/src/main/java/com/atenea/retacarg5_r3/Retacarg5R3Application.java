package com.atenea.retacarg5_r3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Retacarg5R3Application {

    public static void main(String[] args) {
        SpringApplication.run(Retacarg5R3Application.class, args);
    }

}
