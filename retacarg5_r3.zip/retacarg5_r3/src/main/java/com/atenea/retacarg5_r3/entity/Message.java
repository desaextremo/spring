package com.atenea.retacarg5_r3.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;
@Entity
@Table(name = "messages")
@Data
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMessage;
    private String messageText;
    
    //relacion con carro
    @ManyToOne
    @JoinColumn(name="idCar")
    @JsonIgnoreProperties({"messages","reservations"})
    private Car car;
    
    //relacion con cliente
    @ManyToOne
    @JoinColumn(name="idClient")
    @JsonIgnoreProperties({"messages","reservations"})
    private Client client;
}
