package com.atenea.retacarg5_r3.service;


import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {
    @Autowired
    private ClientRepository repository;

    //listar clientes
    public List<Client> getCLients(){
        return repository.findAll();
    }

    //agregar clientes
    public void addClient(Client client){
        repository.save(client);
    }
}
