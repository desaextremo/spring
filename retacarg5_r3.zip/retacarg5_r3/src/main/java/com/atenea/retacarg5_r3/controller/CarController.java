package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Car")
@CrossOrigin(origins = "*")
public class CarController {
    @Autowired
    private CarService businnes;

    //listar carros
    @GetMapping("/all")
    public List<Car> getCars(){
        return businnes.getCars();
    }

    //Recuperar un carro a parti de su id
    @GetMapping("/{id}")
    public Car getCar(@PathVariable("id") Long carId){
        return businnes.getCar(carId);
    }

    //ingresar Carros
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addCar(@RequestBody Car car){
        businnes.addCar(car);
    }

}
