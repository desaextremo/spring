package com.atenea.retacarg5_r3.entity;

import jakarta.persistence.*;

@Entity
@Table(name="cars")
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCar;
    @Column(nullable = false,length = 45 )
    private String name;
    @Column(nullable = false,length = 45 )
    private String brand;
    @Column(nullable = false )
    private int year;
    @Column(nullable = false,length = 250  )
    private String description;
    @ManyToOne
    @JoinColumn(name="gamaId")
    private Gama gama;
}
