package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Gama;
import com.atenea.retacarg5_r3.repository.GamaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
public class GamaService {
    @Autowired
    private GamaRepository repository;

    //listar Gamas
    public List<Gama> getGamas(){
        return repository.findAll();
    }

    //Lista una gama a partir de su id
    public Gama getGama(Long idValue){
        return repository.findById(idValue).get();
    }

    //Registrar Gama
    public void addGama(Gama gama){
        repository.save(gama);
    }
}
