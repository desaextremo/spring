package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Gama;
import com.atenea.retacarg5_r3.repository.GamaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GamaService {
    @Autowired
    private GamaRepository repository;

    //listar Gamas
    public List<Gama> getGamas(){
        return repository.findAll();
    }

    //Registrar Gama
    public void addGama(Gama gama){
        repository.save(gama);
    }
}
