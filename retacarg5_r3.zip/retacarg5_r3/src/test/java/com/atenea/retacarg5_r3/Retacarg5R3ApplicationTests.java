package com.atenea.retacarg5_r3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Retacarg5R3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
