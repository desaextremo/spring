package com.atenea.springconcepts.controller;

import com.atenea.springconcepts.domain.Usuario;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Este controlador rest realizara administracion en memoria de objetos de tipo
 * Cliente.
 *
 * Expondra metodos para crear,actualizar,eliminar y listar o consultar usuarios
 *
 *  el valor del puerto en la url de cada servicio dependera de valor definido en el archivo
 *  * 'application.properties', propiedad: server.port=<puerto>
 * @author desaextremo
 */
@RestController
@RequestMapping("/usuarios")
public class CrudController {
    /**
     * Coleccion o Lista de usuarios para representar un conjunto de usuarios que se vana a administrar
     * insertar,eliminar,actualizar, listar
     *
     * end points:
     *
     * 1 Listar usuarios:
     * localhost:8082/usuarios
     * 2 Buscar usuario por nombre de usuario
     * localhost:8082/usuarios/{username}
     *
     * {username} corresponde a un valor parametrico
     *
     * ej: http://localhost:8082/usuarios/SERPENT
     *
     * 3 insertar usuario: peticion tipo POST, recibe un usuario
     *   en el cuerpo de la peticion, para eso el método java utiliza
     *   la anotación @RequestBody
     *      * localhost:8082/usuarios
     */
    private List<Usuario> usuarios = new ArrayList<>(Arrays.asList(
            new Usuario("SERPENT","SERPENT123","CRHISTIAN OVALLE"),
            new Usuario("NBONAPARTE","NBONAPARTE123","NAPOLEON BONAPARTE"),
            new Usuario("MESTUARDO","MESTUARDO123","MARIA ESTUARDO"),
            new Usuario("QUIQUE8","QUIQUE123","ENRIQUE VIII"),
            new Usuario("JLOCA","JLOCA123","JUANA DE CASTILLA")));

    /**
     * Listar usuarios: devuelve el listado de usuarios
     * @return ArrayList o lista de usuarios
     */
    @GetMapping
    public List<Usuario> getUsuarios(){
        return usuarios;
    }

    /**
     * Busca y obtienen un usuario a partir de su nombre de usuario, o null
     * en caso de no existir coincidencia
     * @param userNameValue nombre del usuario a buscar
     * @return datos del usuario cuyo nombre coincida con el valor recibiso como parametro o null si no hay coincidencia
     */
    @GetMapping("/{username}")
    public Usuario getUsuario(@PathVariable("username") String userNameValue){
        for (Usuario usuario : usuarios){
            if(usuario.getUsername().equalsIgnoreCase(userNameValue)) {
                return usuario;
            }
        }
        return null;
    }

    /**
     * Ingresa un usuario al listado, la información
     * dl usuario se envia en formato json desde la aplicación
     * cliente que consume el servicio, Spring Boot se encarga de
     * convertir ese JSON a un objeto de tipo usuario para ingresarlo
     * en la lista 'usuarios'
     * {
     *     "username":"DESAEXTREMO",
     *      "password":"DESAEXTREMO123",
     *      "nombre":"CRHISTIAN OVALLE GAMBA"
     * }
     *
     * @param usuario un usuario
     * @return usuario agregado al listado
     */
    @PostMapping
    public Usuario insertarUsuario(@RequestBody Usuario usuario){
        //Antes de ingresar el usuario al listado valida si no existe
        //un usuario con el mismo nombre
        if (getUsuario(usuario.getUsername())==null){
            usuarios.add(usuario);
            return usuario;
        }
        return null;
    }
    /**
     * Actualiza un usuario del listado, la información
     * dl usuario se envia en formato json desde la aplicación
     * cliente que consume el servicio, Spring Boot se encarga de
     * convertir ese JSON a un objeto de tipo usuario para ingresarlo
     * en la lista 'usuarios'
     * {
     *   "username":"DESAEXTREMO",
     *   "password":"DESAEXTREMO123",
     *   "nombre":"CRHISTIAN OVALLE GAMBA"
     * }
     * @param usuario un usuario a modificar
     * @return usuario modificado o null si el usuario no existe
     */
    @PutMapping
    public Usuario modificarUsuario(@RequestBody Usuario usuario){
        Usuario usuarioABuscar = getUsuario(usuario.getUsername());
        if (usuarioABuscar != null){
            usuarioABuscar.setName(usuario.getName());
            usuarioABuscar.setPassword(usuario.getPassword());
            return usuario;
        }
        return null;
    }

    /**
     * Elimina un usuario del la lista 'usuarios'
     * Busca un nombre de usuario que coincida con el valor
     * recibido como parametro y lo elimina del listado 'usuarios'
     * si existe en el listado
     * @param userNameValue Nombre del usuario a eliminar
     */
    @DeleteMapping("/{username}")
    public void eliminarUsuario(@PathVariable("username") String userNameValue){
        Usuario usuarioABuscar = getUsuario(userNameValue);
        if (usuarioABuscar !=null){
            usuarios.remove(usuarioABuscar);
        }
    }
}
