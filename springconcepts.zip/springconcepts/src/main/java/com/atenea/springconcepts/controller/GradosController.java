package com.atenea.springconcepts.controller;

import org.springframework.web.bind.annotation.*;

/**
 * Controlador rest para convertir temperatura expresada en grados
 * end points:
 * para todos los casos el valor es parametrico, aunque en el ejemplo tenga un valor de 50
 * el valor del puerto en la url de cada servicio dependera de valor definido en el archivo
 * 'application.properties', propiedad: server.port=<puerto>
 *
 * 1 localhost:8082/grados/centofarenh/50
 * 2 localhost:8082/grados/farenhtocent/50
 * 3 localhost:8082/grados/centokelvin/50
 * 4 localhost:8082/grados/kelvintocent/50
 * @author desaextremo
 */
@RestController
@RequestMapping("/grados")
@CrossOrigin(origins = "*")
public class GradosController {
    /**
     * Convertir grados centigrados a grados farenheit
     * @param gradosEnCentigrados grados en unidades centigrados
     * @return grados en unidades farenheit
     */
    @GetMapping("/centofarenh/{graditos}")
    public double centigradosAFarenheit(@PathVariable("graditos") double gradosEnCentigrados){
        double resultado;
        resultado = (9f / 5f) * (gradosEnCentigrados + 32);
        return resultado;
    }

    /**
     * Convertir grados farenheit a grados centigrados
     * @param gradosEnFarenheit grados en unidades farenheit
     * @return grados en unidades centigrados
     */
    @GetMapping("/farenhtocent/{graditos}")
    public double farenheitACentigrados(@PathVariable("graditos") double gradosEnFarenheit){
        double resultado;
        resultado = (5f /9f) * (gradosEnFarenheit - 32);
        return resultado;
    }

    /**
     * Convertir grados centigrados a grados kelvin
     * @param gradosEnCentigrados grados en unidades centigrados
     * @return grados en unidades kelvin
     */
    @GetMapping("/centokelvin/{graditos}")
    public double centigradosAKelvin(@PathVariable("graditos") double gradosEnCentigrados){
        double resultado;
        resultado = gradosEnCentigrados + 273;
        return resultado;
    }

    /**
     * Convertir grados centigrados a grados kelvin
     * @param gradosEnKelvin grados en unidades centigrados
     * @return grados en unidades centigrados
     */
    @GetMapping("/kelvintocent/{graditos}")
    public double kelvinACentigrados(@PathVariable("graditos") double gradosEnKelvin){
        double resultado;
        resultado = gradosEnKelvin - 273;
        return resultado;
    }
}
