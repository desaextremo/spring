package com.atenea.springconcepts.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;

@Entity
@Data

@Table(name="misclientes")
public class Cliente implements Serializable {
    //atributos
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //@Column(name="cli_name",nullable = true,length = 50)
    //@Column(name = "cli_name", columnDefinition = "varchar(50) not null")
    @Column(name="cli_name",nullable = false,length = 50)
    private String name;
    //@Column(name = "cli_email", columnDefinition = "varchar(50) not null")
    @Column(name="cli_email",nullable = false,length = 50)
    private String email;
    @Column(name="cli_age",nullable = false)
    //@Column(name = "cli_age", columnDefinition = "int(11) not null")
    private Long age;

}

