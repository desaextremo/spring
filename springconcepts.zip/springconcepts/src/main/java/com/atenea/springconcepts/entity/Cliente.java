package com.atenea.springconcepts.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="misclientes")
public class Cliente implements Serializable {
    //atributos
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private Long age;

}

