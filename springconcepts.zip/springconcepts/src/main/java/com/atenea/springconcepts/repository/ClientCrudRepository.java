package com.atenea.springconcepts.repository;

import com.atenea.springconcepts.entity.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Cliente, Long> {

}
