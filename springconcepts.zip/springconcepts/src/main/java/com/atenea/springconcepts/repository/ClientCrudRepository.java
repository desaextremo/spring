package com.atenea.springconcepts.repository;

import com.atenea.springconcepts.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientCrudRepository extends JpaRepository<Cliente, Long> {

}
