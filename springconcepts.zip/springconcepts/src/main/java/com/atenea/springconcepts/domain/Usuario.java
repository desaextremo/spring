package com.atenea.springconcepts.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Esta clase Representa a un usuario, se utilizara en el controlador rest
 * 'CrudController' para administrar usuario: insertar, actaulizar, eliminar y consultar
 * la administración de los usuario inicialmente se hara en memoria.
 * Utilizaremos la anotacion @Data de Lombok para evitar crear los metodos get y set
 * la notación @NoArgsConstructor para el constructor por defecto o constructor sin argumentos
 * la notación @AllArgsConstructor se utilizara para que lombok cree automaticamente los constructores
 * que sean necesarios
 *
 * @author desaextremo
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    /**
     * usuario de acceso
     */
    private String username;
    /**
     * clave de acceso
     */
    private String password;
    /**
     * nombre del usuario
     */
    private String name;
}
