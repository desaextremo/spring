package com.atenea.springconcepts.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Esta clase representa un controlador basico de spring
 * usa la anotacion @RestController para indicar que la clase
 * 'HolaMundoController' sera un controlador rest que expondra varios
 * 'endpoints' o servicios. Estos serán los metodos de esta clase; aunque solo
 * aquellos que incluyan las anotaciones para manejo de peticiones http:
 * get: @GetMapping para exponer servicios que puedan procesar peticiones get
 * post: @PostMapping para exponer servicios que puedan procesar peticiones post
 * put: @PutMapping para exponer servicios que puedan procesar peticiones put
 * delete: @DeleteMapping para exponer servicios que puedan procesar peticiones delete
 *
 * La anotacion @RequestMapping se utiliza para unificar el nombre del controlador y los servicios
 * de forma tal que cada servicio o 'end point' incluya en su url o identificacdor de recurso, el
 * nombre alli definido:
 * Para nuestro caso que el nombre definido mediante la anotacion fue "/basico", la url de los 2 servicios
 * expuestos qeudaran asi:
 * url: <protocolo>:<puerto>/<nombre definido por @RequestMapping>/<url de cada servicio>
 * <protocolo>: http o https según el caso
 * <puerto>: por defecto se usa '8080', pero puede modificarse en el archivo 'application.properties' mediante
 * la propiedad 'server.port'
 * <url de cada servicio>: valor ubicado entre parentesis y comillas dobles en las
 * anotaciones: @GetMapping @PostMapping,@PutMapping y/o @DeleteMapping
 *
 * End point 1 (GET): localhost:8080/basico/saludo
 * End point 2 (GET): localhost:8080/basico/saludo/Juan
 *
 * La anotacion: @PathVariable se utiliza para el paso de parametros desde la url a los metodos
 * 1 Agregar la anotación  @PathVariable("<nombre parametro>") en la firma del metodo (tantas veces
 * como parametros reciba el metodo requiera)
 * 2 Modificar la url o end point para indicar que recibira un parametro:
 * {"<nombre parametro>"}
 * La anotacion @CrossOrigin(origins = "*") se utiliza para permitir que el front pueda
 * consumir los servicios expuestos en el controlador Rest
 * @author desaextremo
 */
@RestController
@RequestMapping("/basico")
public class HolaMundoController {
    @GetMapping("/saludo")
    public String saludo(){
        System.out.println("Ejecutando metodo saludo mediante peticion 'Get'");
        return "Hola mundo";
    }
    @GetMapping("/saludo/{nombre}")
    public String saludoParametro(@PathVariable("nombre") String valorNombre){
        System.out.println("Ejecutando metodo saludo con parametros mediante peticion 'Get'");
        return "Hola " + valorNombre;
    }
}
