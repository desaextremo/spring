
package com.atenea.springconcepts.controller;

import com.atenea.springconcepts.entity.Cliente;
import com.atenea.springconcepts.repository.ClientCrudRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Este controlador rest realizara administracion en memoria de objetos de tipo
 * Cliente.
 *
 * Expondra metodos para crear,actualizar,eliminar y listar o consultar usuarios
 *
 *  el valor del puerto en la url de cada servicio dependera de valor definido en el archivo
 *  * 'application.properties', propiedad: server.port=<puerto>
 * @author desaextremo
 */

@RestController
@RequestMapping("/clients")
public class ClientController {
    
    @Autowired
    private ClientCrudRepository repository;
    
    @GetMapping
    public List<Cliente> getClients(){
        return repository.findAll();
    }
}
