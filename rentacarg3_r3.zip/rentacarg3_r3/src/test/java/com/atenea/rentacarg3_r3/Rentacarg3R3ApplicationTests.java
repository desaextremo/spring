package com.atenea.rentacarg3_r3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rentacarg3R3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
