package com.atenea.rentacarg3_r3.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.util.List;
import lombok.Data;

@Entity
@Table(name="gamas")
@Data
public class Gama {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idGama;
    @Column(nullable = false,length = 45 )
    private String name;
    @Column(nullable = false,length = 250 )
    private String description;
    
    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "gama")
    @JsonIgnoreProperties("gama")
    private List<Car> cars;
}
