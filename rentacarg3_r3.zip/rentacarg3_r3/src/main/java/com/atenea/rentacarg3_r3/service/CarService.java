package com.atenea.rentacarg3_r3.service;

import com.atenea.rentacarg3_r3.entity.Car;
import com.atenea.rentacarg3_r3.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {
    @Autowired
    private CarRepository repository;

    //consultar los carros
    public List<Car> getCars(){
        return repository.findAll();
    }

    //insertar un carro
    public void addCar(Car car){
        repository.save(car);
    }
}
