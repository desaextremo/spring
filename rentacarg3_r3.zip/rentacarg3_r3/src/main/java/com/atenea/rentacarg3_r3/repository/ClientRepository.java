package com.atenea.rentacarg3_r3.repository;


import com.atenea.rentacarg3_r3.entity.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client,Long> {
}
