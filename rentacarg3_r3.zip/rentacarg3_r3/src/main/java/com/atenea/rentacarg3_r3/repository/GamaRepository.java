package com.atenea.rentacarg3_r3.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.atenea.rentacarg3_r3.entity.Gama;

public interface GamaRepository extends JpaRepository<Gama,Long> {
}
