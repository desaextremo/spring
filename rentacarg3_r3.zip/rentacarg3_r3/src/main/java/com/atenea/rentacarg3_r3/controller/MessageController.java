package com.atenea.rentacarg3_r3.controller;

import com.atenea.rentacarg3_r3.entity.Message;
import com.atenea.rentacarg3_r3.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Message/")
@CrossOrigin(origins = "*")
public class MessageController {
    @Autowired
    private MessageService businness;

    //Listar mensajes
    @GetMapping("/all")
    public List<Message> getMessages(){
        return businness.getMessages();
    }

    //agregar mensaje
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addMessage(@RequestBody Message message){
        businness.addMessage(message);
    }
}
