package com.atenea.rentacarg3_r3.service;

import com.atenea.rentacarg3_r3.entity.Gama;
import com.atenea.rentacarg3_r3.repository.GamaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Service
public class GamaService {
    @Autowired
    private GamaRepository repositorio;

    //Listar las gamas de autos
    public List<Gama> getGamas(){
        return repositorio.findAll();
    }

    //Insertar una gama
    public void addGama(Gama gama){
        repositorio.save(gama);
    }
}
