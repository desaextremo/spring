package com.atenea.rentacarg3_r3.entity;

public class Admin {
}
