//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Message/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let botonNuevoMensaje =  document.getElementById("botonNuevoMensaje")
let botonAplicarNuevoMensaje =  document.getElementById("botonAplicarNuevoMensaje")
let clienteMensaje = document.getElementById("clienteMensaje")
let carroMensaje = document.getElementById("carroMensaje")
let msgError = document.getElementById("msgError")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoMensaje.addEventListener("click",nuevaMensaje)
botonAplicarNuevoMensaje.addEventListener("click",aplicarMensaje)
bottonCancelarNuevo.addEventListener("click",inicial)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaMensaje(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('nameCarro').value=""
    document.getElementById('descriptionCarro').value=""
    document.getElementById('nameCarro').focus()
}

function inicial(){
    document.getElementById('descriptionMensaje').value=""
    document.getElementById('clienteMensaje').value=""
    document.getElementById('carroMensaje').value=""
    seccionNuevo.style.display="none"
    msgError.style.display="none"
    listar()
    llenaListaClientes()
    llenaListaCarros()
}

function aplicarMensaje (){
    url = "http://localhost:8080/api/Message/save"

    //leer datos del formulario
    let descriptionMensaje = document.getElementById('descriptionMensaje').value
    let clienteMensaje = document.getElementById('clienteMensaje').value
    let carroMensaje = document.getElementById('carroMensaje').value

    if ((clienteMensaje==0) || (carroMensaje==0)){
        msgError.innerHTML="Debe seleccionar el cliente y el carro"
        msgError.style.display="block"
    }else{
        //generar peticion tipo post con la libreria axios
        axios.post(url,{
            messageText: descriptionMensaje,
            client: {
                idClient: clienteMensaje
            },
            car: {
                idCar: carroMensaje
            }
        })
        .then(function (response){
            console.log(response.data)
            inicial()
        })
        .catch(function (error){
            console.log(error)
        })
    }
}

function listar(){
    url="http://localhost:8080/api/Message/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idMessage + ' </td>' + 
                            '<td>' + items[i].client.name +'</td>' +
                            '<td>' + items[i].car.name + ' - ' + items[i].car.brand + '</td>' +
                            '<td>' + items[i].messageText + '</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary">Editar</button>' +
                            '    <button class="btn btn-outline-primary">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaClientes(){
    url="http://localhost:8080/api/Client/all"
    let listaClientes="<option value=0>Selecciones un cliente...</option>"
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaClientes +=  '<option value="' + items[i].idClient + '">' + items[i].name +'</option>'
        }
        clienteMensaje.innerHTML = listaClientes
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaCarros(){
    url="http://localhost:8080/api/Car/all"
    let listaCarros="<option value=0>Seleccione un carro...</option>"
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaCarros +=  '<option value="' + items[i].idCar + '">' + items[i].name + ' - ' + items[i].brand +'</option>'
        }
        carroMensaje.innerHTML = listaCarros
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}
