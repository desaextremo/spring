package com.testdiego.diego;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class BookDto implements Serializable {
    private String title;
    private String author;
    private String isbn;
    private double price;
    private String category;
    private String description;
}
