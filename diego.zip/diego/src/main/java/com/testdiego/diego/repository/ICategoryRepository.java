package com.testdiego.diego.repository;

import com.testdiego.diego.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author cjovalle
 */
@Repository
public interface ICategoryRepository extends JpaRepository<Category, Long>{
    
}
