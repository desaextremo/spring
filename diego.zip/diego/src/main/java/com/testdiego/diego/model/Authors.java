package com.testdiego.diego.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;

@Entity()
@Data
@Table(name = "LIB_AUTHORS")
public class Authors  implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AUT_ID")
    private Long id;

    @Column(name = "AUT_FIRST_NAME")
    private String firstName;
    @Column(name = "AUT_LAST_NAME")
    private String lastName;
    @Column(name = "AUT_DATE_DOB")
    private LocalDate birthDate;
    @Column(name = "AUT_GENDER")
    private  String gener;
    @Column(name = "AUT_CONTACT")
    private  String contactInfo;
    @Column(name = "AUT_OTHER_DETAILS")
    private String otherDetails;

}
