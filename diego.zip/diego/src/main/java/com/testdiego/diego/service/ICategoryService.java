package com.testdiego.diego.service;


import com.testdiego.diego.CategoryDto;
import java.util.List;

/**
 *
 * @author cjovalle
 */
public interface ICategoryService {
    List<CategoryDto> getCategories();
    
    CategoryDto getCategoryById(Long id);
}
