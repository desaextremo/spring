package com.testdiego.diego.Controller;

import com.testdiego.diego.BookDto;
import com.testdiego.diego.service.IBookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/book")
public class BookController {
    @Autowired
    private final IBookService bookService;
    @GetMapping("/{category}")
    private List<BookDto> getBooksByCategory(@PathVariable("category") Long category){
        List<BookDto> bookDtos=bookService.getBooksForCategory(category);
        return bookDtos;
    }
}
