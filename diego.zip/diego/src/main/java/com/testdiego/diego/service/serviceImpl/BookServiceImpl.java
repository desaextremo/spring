package com.testdiego.diego.service.serviceImpl;

import com.testdiego.diego.BookDto;
import com.testdiego.diego.model.Book;
import com.testdiego.diego.repository.IBookRepository;
import com.testdiego.diego.service.IBookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements IBookService {

    private  final IBookRepository bookRepository;
    @Override
    public List<BookDto> getBooksForCategory(Long category) {
        List<Book> books=bookRepository.findByCategory((category));
        List<BookDto> result=books.stream().map((book ->
                BookDto.builder().category(book.getCategory().getDescription())
                        .title(book.getTitle())
                        .price(book.getPrice())
                        .author(book.getAuthor().getFirstName() + " "+ book.getAuthor().getLastName())
                        .isbn(book.getIsbn())
                        .description(book.getDescripcion())
                        .build() )).collect(Collectors.toList());
        return result;
    }
}
