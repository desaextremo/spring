package com.testdiego.diego.repository;

import com.testdiego.diego.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IBookRepository extends JpaRepository<Book,Long> {
   @Query(value="select  B from Book B WHERE B.category.id=:id order by B.author.firstName,B.author.lastName,B.title")
    List<Book> findByCategory(Long id);
}
