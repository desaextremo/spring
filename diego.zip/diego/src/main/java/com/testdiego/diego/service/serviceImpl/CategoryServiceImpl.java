package com.testdiego.diego.service.serviceImpl;

import com.testdiego.diego.BookDto;
import com.testdiego.diego.CategoryDto;
import com.testdiego.diego.model.Category;
import com.testdiego.diego.repository.ICategoryRepository;
import com.testdiego.diego.service.ICategoryService;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 *
 * @author cjovalle
 */
@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements ICategoryService{
    
    private  final ICategoryRepository categoryRepository;
    @Override
    public List<CategoryDto> getCategories() {
        List<Category> categories = categoryRepository.findAll();
        List<CategoryDto> categoriesDTO = new ArrayList<CategoryDto>();
        CategoryDto categoryDto;
        for (Category category : categories) {
            
            categoryDto = CategoryDto.builder().id(category.getId()).description(category.getDescription()).build();
            categoriesDTO.add(categoryDto);
        }
        return categoriesDTO;
    }

    @Override
    public CategoryDto getCategoryById(Long id) {
        Category category = categoryRepository.findById(id).get();
        
        return CategoryDto.builder().id(category.getId()).description(category.getDescription()).build();
    }  
}
