package com.testdiego.diego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiegoApplication.class, args);
	}

}
