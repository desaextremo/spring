package com.testdiego.diego.service;

import com.testdiego.diego.BookDto;

import java.util.List;

public interface IBookService {
    List<BookDto> getBooksForCategory(Long id);
}
