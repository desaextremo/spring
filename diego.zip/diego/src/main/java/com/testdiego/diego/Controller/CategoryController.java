package com.testdiego.diego.Controller;

import com.testdiego.diego.CategoryDto;
import com.testdiego.diego.service.ICategoryService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author cjovalle
 */
@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/category")
public class CategoryController {
    @Autowired
    private final ICategoryService categoryService;
    @GetMapping("")
    private List<CategoryDto> getCategories(){
        List<CategoryDto> categoriesDtos=categoryService.getCategories();
        return categoriesDtos;
    }
    
    @GetMapping("/{id}")
    public CategoryDto getCategoryById(@PathVariable("id") Long id){
        return categoryService.getCategoryById(id);
    }
}
