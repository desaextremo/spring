package com.testdiego.diego;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiegoApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
