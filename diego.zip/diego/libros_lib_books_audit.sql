-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: libros
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lib_books_audit`
--

DROP TABLE IF EXISTS `lib_books_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lib_books_audit` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `BOOK_ID` int DEFAULT NULL,
  `FECHA` datetime DEFAULT NULL,
  `ACCION` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lib_books_audit`
--

LOCK TABLES `lib_books_audit` WRITE;
/*!40000 ALTER TABLE `lib_books_audit` DISABLE KEYS */;
INSERT INTO `lib_books_audit` VALUES (1,1,'2022-09-06 16:15:16','insert'),(2,2,'2022-09-06 16:15:16','insert'),(3,3,'2022-09-06 16:15:16','insert'),(4,4,'2022-09-06 16:15:16','insert'),(5,5,'2022-09-06 16:15:16','insert'),(6,6,'2022-09-06 16:15:16','insert'),(7,7,'2022-09-06 16:15:16','insert'),(8,8,'2022-09-06 16:15:16','insert'),(9,9,'2022-09-06 16:15:16','insert'),(10,10,'2022-09-06 16:15:16','insert'),(11,11,'2022-09-06 16:15:16','insert'),(12,12,'2022-09-06 16:15:16','insert'),(13,13,'2022-09-06 16:15:16','insert'),(14,14,'2022-09-06 16:15:16','insert'),(15,15,'2022-09-06 16:15:16','insert'),(16,16,'2022-09-06 16:15:16','insert'),(17,17,'2022-09-06 16:15:16','insert'),(18,18,'2022-09-06 16:15:16','insert'),(19,19,'2022-09-06 16:15:16','insert'),(20,20,'2022-09-06 16:15:16','insert'),(21,21,'2022-09-06 16:15:16','insert'),(22,22,'2022-09-06 16:15:16','insert'),(23,23,'2022-09-06 16:15:16','insert'),(24,24,'2022-09-06 16:15:16','insert'),(25,25,'2022-09-06 16:15:16','insert'),(26,26,'2022-09-06 16:15:16','insert'),(27,27,'2022-09-06 16:15:16','insert'),(28,28,'2022-09-06 16:15:16','insert'),(29,29,'2022-09-06 16:15:16','insert'),(30,30,'2022-09-06 16:15:16','insert'),(31,31,'2022-09-06 16:15:16','insert'),(32,32,'2022-09-06 16:15:16','insert'),(33,33,'2022-09-06 16:15:16','insert'),(34,34,'2022-09-06 16:15:16','insert'),(35,35,'2022-09-06 16:15:16','insert'),(36,36,'2022-09-06 16:15:16','insert'),(37,37,'2022-09-06 16:15:16','insert'),(38,38,'2022-09-06 16:15:16','insert');
/*!40000 ALTER TABLE `lib_books_audit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-21 11:23:26
