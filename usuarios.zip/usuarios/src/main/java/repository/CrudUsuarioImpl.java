package repository;

import com.atenea.usuarios.domain.Usuario;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author desaextremo
 */
public class CrudUsuarioImpl implements CrudUsuario{
    
    private List<Usuario> usuarios;
    private Usuario usuario;
    
     //simular datos pre cargados en una coleccion o lista
    public CrudUsuarioImpl() {
       
        usuarios = new ArrayList<>(Arrays.asList(
            new Usuario("SERPENT","SERPENT123","CRHISTIAN OVALLE"),
            new Usuario("NBONAPARTE","NBONAPARTE123","NAPOLEON BONAPARTE"),
            new Usuario("MESTUARDO","MESTUARDO123","MARIA ESTUARDO"),
            new Usuario("QUIQUE8","QUIQUE123","ENRIQUE VIII"),
            new Usuario("JLOCA","JLOCA123","JUANA DE CASTILLA")));
    }
    
    @Override
    public Usuario buscarUsuario(String userName) {
        usuario = null ;
        //buscar un usuario a partir de sus nombre: buscaremos el usuario de nombre DESAEXTREMO
        for (Usuario user : usuarios) {
            //si el nombre del usuario en la coleccion es 'DESAEXTREMO'
            //asigna el usuario que actualmente esta en la iteraccion de la coleccion
            //a la variable usuario y retorna
            if (user.getUsername().equals(userName)){
                usuario = user;
            }
        }
        
        return usuario;
    }

    @Override
    //si no existe un usuario con ese id en la coleccion
    public Usuario agregarUsuario(Usuario usuario) {
        if (buscarUsuario(usuario.getUsername())==null){
            usuarios.add(usuario);
            return usuario;
        }
        else return null;
    }
    
    @Override
    public Usuario modificarUsuario(Usuario unUsuario) {
        
        if (buscarUsuario(unUsuario.getUsername())!=null){
            usuario.setName(unUsuario.getName());
            usuario.setPassword(unUsuario.getPassword());
            return usuario;
        }else return null;
    }

    @Override
    public boolean borrarUsuario(Usuario usuario) {
        if (buscarUsuario(usuario.getUsername())!=null){
            usuarios.remove(usuario);
            return true;
        }else return false;
    }    

    @Override
    public List<Usuario> listarUusuarios() {
        return usuarios;
    }
}
