package repository;

import com.atenea.usuarios.domain.Usuario;
import java.util.List;

/**
 * Interface que expone metodos que una clase debe implementar
 * @author desaextremo
 */
public interface CrudUsuario {
    public Usuario buscarUsuario(String userName);
    public Usuario agregarUsuario(Usuario usuario);
    public Usuario modificarUsuario(Usuario usuario);
    public boolean borrarUsuario(Usuario usuario);
    public List<Usuario> listarUusuarios();
}
