package com.atenea.usuarios;

import com.atenea.usuarios.domain.Usuario;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import repository.CrudUsuarioImpl;

/**
 * Esta clase muestra 
 * @author desaextremo
 */
public class AdministrarUsuarios {

    public static void main(String[] args) {
        
        //instancia la clase 'CrudUsuarioImpl'
        CrudUsuarioImpl crud = new CrudUsuarioImpl();
        
        Usuario usuario = null ;
        
        //listar usuarios
        System.out.println("-------------------------------------------");
        System.out.println("Listado de usuarios (inicial)");
        System.out.println("-------------------------------------------");
        for (Usuario user : crud.listarUusuarios()) {
            System.out.println(user.toString());
        }
        
        //Agregar un usuario
        usuario = crud.agregarUsuario(new Usuario("DESAEXTREMO","DESAEXTR","CRHISTIAN OVALLE"));
        
        //listar usuarios
        System.out.println("-------------------------------------------");
        System.out.println("Listado de usuarios (despues del insert)");
        System.out.println("-------------------------------------------");
        for (Usuario user : crud.listarUusuarios()) {
            System.out.println(user.toString());
        }
        
        //Modificar usuario
        usuario = new Usuario("DESAEXTREMO","SARA123","SARA OVALLE");
        crud.modificarUsuario(usuario);
        
        //listar usuarios
        System.out.println("-------------------------------------------");
        System.out.println("Listado de usuarios (despues de actualizar)");
        System.out.println("-------------------------------------------");
        for (Usuario user : crud.listarUusuarios()) {
            System.out.println(user.toString());
        }
        
        
        //eliminar un usuario
        crud.borrarUsuario(usuario);
        
        //listar usuarios
        System.out.println("-------------------------------------------");
        System.out.println("Listado de usuarios (despues de eliminar)");
        System.out.println("-----------------------------------------");
        for (Usuario user : crud.listarUusuarios()) {
            System.out.println(user.toString());
        }
    }
}
