package com.usa.rentcar.repository.crud;

import com.usa.rentcar.model.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin,Integer> {

}
