package com.usa.rentcar.repository.crud;

import com.usa.rentcar.model.Score;
import org.springframework.data.repository.CrudRepository;

public interface ScoreCrudRepository extends CrudRepository<Score,Integer> {

}
