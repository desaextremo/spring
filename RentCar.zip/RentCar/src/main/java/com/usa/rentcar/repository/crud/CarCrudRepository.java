package com.usa.rentcar.repository.crud;

import com.usa.rentcar.model.Car;
import com.usa.rentcar.model.custom.CountCar;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CarCrudRepository extends CrudRepository<Car,Integer> {

}
