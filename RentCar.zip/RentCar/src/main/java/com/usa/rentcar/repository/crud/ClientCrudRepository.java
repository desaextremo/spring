package com.usa.rentcar.repository.crud;

import com.usa.rentcar.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client,Integer> {

}
