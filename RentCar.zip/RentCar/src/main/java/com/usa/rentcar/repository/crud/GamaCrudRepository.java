package com.usa.rentcar.repository.crud;

import com.usa.rentcar.model.Gama;
import org.springframework.data.repository.CrudRepository;

public interface GamaCrudRepository extends CrudRepository<Gama,Integer> {

}
