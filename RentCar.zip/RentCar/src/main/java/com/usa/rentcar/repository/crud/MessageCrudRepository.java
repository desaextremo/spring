package com.usa.rentcar.repository.crud;


import com.usa.rentcar.model.Message;
import org.springframework.data.repository.CrudRepository;

public interface MessageCrudRepository extends CrudRepository<Message,Integer> {

}
