package com.usergio.retos.retoapp.custom;

import com.usergio.retos.retoapp.modelo.entidad.Car;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Builder
public class CountCar {
    private Long total;
    private Car car;
}
