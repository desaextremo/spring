package com.usergio.retos.retoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoappApplicationTests {

    @Test
    void contextLoads() {
    }

}
