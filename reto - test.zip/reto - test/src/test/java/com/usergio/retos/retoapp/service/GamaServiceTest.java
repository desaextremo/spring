package com.usergio.retos.retoapp.service;

import com.usergio.retos.retoapp.modelo.entidad.Car;
import com.usergio.retos.retoapp.modelo.entidad.Gama;
import com.usergio.retos.retoapp.modelo.repositorio.GamaRepository;
import jakarta.annotation.Resource;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class GamaServiceTest {
    @Resource
    GamaService service;

    @Test
    @DisplayName("Prueba Guardar Gama")
    void save() {
        Gama gama = Gama.builder().name("Familiar").description("Auto Familiar").build();
        assertEquals(gama,service.save(gama));
    }
    @Test
    @DisplayName("Prueba Listar Gama")
    void findByAll() {
         Gama gamaExpect = Gama.builder().idGama(2L).name("Familiar").description("Auto Familiar").build();
        Gama gama = Gama.builder().name("Familiar").description("Auto Familiar").build();
        service.save(gama);
        List<Gama> gamasResult = service.getAll();
        List<Gama> gamasExpect = new ArrayList<>();
        gamasExpect.add(gamaExpect);
        assertEquals(gamasExpect,gamasResult);
    }

    //@Test
    @DisplayName("Prueba Listar Gama")
    void findByAl1l() {
        List<Car> cars = new ArrayList<Car>();
        Gama gamaExpect = Gama.builder().idGama(3L).name("Sedan").description("Vehiculo ligero para transitar en la ciudad").cars(cars).build();
        List<Gama> gamasResult = service.getAll();
        List<Gama> gamasExpect = new ArrayList<>();
        gamasExpect.add(gamaExpect);
        assertEquals(gamasExpect,gamasResult);
    }

    @Test
    @DisplayName("Actualizar Gama")
    void editar() {
        Gama gamaMod = Gama.builder().idGama(1L).name("Familiar Colombia").description("Auto Familiar Colombia").build();
        assertEquals(gamaMod,service.updateGama(gamaMod));
    }

    @Test
    @DisplayName("Eliminar Gama")
    void eliminar() {
        service.deleteGama(1L);
        Gama gama = new Gama();
        if(!service.getFindById(1L).isPresent()){
            gama = null;
        }
        assertEquals(null,gama);
    }
}