//obtener referencia a la caja de pregunta
let cajaPregunta = document.getElementById("pregunta")
//obtener referencia al titulo de resultados
let tituloResultado = document.getElementById("tituloResultado");
//obtener referencia al mensaje de resultados
let mensajeResultado = document.getElementById("mensajeResultado");
//obtener referencia al boton
let botonAceptar = document.getElementById("botonAceptar")
//obtener referencia al boton
let botonLimpiar = document.getElementById("botonLimpiar")

//definir oyente de eventos de clic sobre el boton
botonAceptar.addEventListener("click", realizarPregunta)
//definir oyente de eventos de clic sobre el boton
botonLimpiar.addEventListener("click", limpiarCampos)
//ubica el cursor o foco en la caja de pregunta
cajaPregunta.focus()
//titulo invisible
tituloResultado.style.display = "none";

function realizarPregunta(){
    //variable para establecer la utl del servicio a invocar
    let url = "http://localhost:8080/questions/send"
    
    //variable para capturar el mensaje
    let mensaje = cajaPregunta.value

    //peticion al servicio web
    axios.post(url,
               {mensaje},
               {headers: {'Content-Type': 'text/plain'}}
               )
    .then(function (response) {
        console.log(response.data)
        //Obtiene respuesta y la agrega a la sección de la pagina
        mensajeResultado.innerHTML = response.data.data

        //activa el boton aceptar, y la caja de texto de la pregunta
        //titulo invisible
        tituloResultado.style.display = "block";
        botonAceptar.disabled = true
        cajaPregunta.disabled = true
    })
    .catch(function (error) {
        // manejar error
        console.log(error)
    });    
}

//Función encargada de limpiar la caja de texto, el resultado
function limpiarCampos(){
    //inactiva el boton aceptar, y la caja de texto de la pregunta
    botonAceptar.disabled = false
    cajaPregunta.disabled = false
    cajaPregunta.value = ""
    mensajeResultado.innerHTML = ""
    //titulo invisible
    tituloResultado.style.display = "none";
    cajaPregunta.focus()
}