//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Car/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let botonNuevoCarro =  document.getElementById("botonNuevoCarro")
let botonApliCarroNuevoCarro =  document.getElementById("botonApliCarroNuevoCarro")
let gamaCarro = document.getElementById("gamaCarro")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoCarro.addEventListener("click",nuevaCarro)
botonApliCarroNuevoCarro.addEventListener("click",aplicarNuevoCarro)
bottonCancelarNuevo.addEventListener("click",inicial)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaCarro(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('nameCarro').value=""
    document.getElementById('descriptionCarro').value=""
    document.getElementById('nameCarro').focus()
}

function inicial(){
    seccionNuevo.style.display="none"
    listar()
    llenaListaGamas()
}

function aplicarNuevoCarro (){
    url = "http://localhost:8080/api/Car/save"

    //leer datos del formulario
    let nameCarro = document.getElementById('nameCarro').value
    let brandCarro = document.getElementById('brandCarro').value
    let yearCarro = document.getElementById('yearCarro').value
    let gamaCarro = document.getElementById('gamaCarro').value
    let descriptionCarro = document.getElementById('descriptionCarro').value

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        name: nameCarro,
        brand: brandCarro,
        year: yearCarro,
        gama: {
            idGama: gamaCarro
        },
        description: descriptionCarro
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function listar(){
    url="http://localhost:8080/api/Car/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idCar + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].brand + '</td>' +
                            '<td>' + items[i].year + '</td>' +
                            '<td>' + items[i].gama.name + '</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary">Editar</button>' +
                            '    <button class="btn btn-outline-primary">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaGamas(){
    url="http://localhost:8080/api/Gama/all"
    let listaGamas=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaGamas +=  '<option value="' + items[i].idGama + '">' + items[i].name +'</option>'
        }
        gamaCarro.innerHTML = listaGamas
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}
